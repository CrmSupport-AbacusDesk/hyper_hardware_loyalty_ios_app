import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CancelpolicymodalPage } from './cancelpolicymodal';

@NgModule({
  declarations: [
    CancelpolicymodalPage,
  ],
  imports: [
    IonicPageModule.forChild(CancelpolicymodalPage),
  ],
})
export class CancelpolicymodalPageModule {}
