import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { DbserviceProvider } from '../../../providers/dbservice/dbservice';
import { TabsPage } from '../../tabs/tabs';
import { BarcodeScanner,BarcodeScannerOptions } from '@ionic-native/barcode-scanner';
import { HomePage } from '../../home/home';
import { Geolocation } from '@ionic-native/geolocation';
import { LocationAccuracy } from '@ionic-native/location-accuracy';
import { TranslateService } from '@ngx-translate/core';



@IonicPage()
@Component({
  selector: 'page-coupan-code',
  templateUrl: 'coupan-code.html',
})
export class CoupanCodePage {
  
  qr_code:any='';
  data:any={};
  flag:any='';
  success_gif:any;
  gif_url="https://apps.abacusdesk.com/PlusPointLock/dd_api/app/uploads/"
  
        
  constructor(public navCtrl: NavController, public navParams: NavParams,public service:DbserviceProvider,public alertCtrl:AlertController,private barcodeScanner: BarcodeScanner, private geolocation: Geolocation,public locationaccuracy: LocationAccuracy, public translate:TranslateService) {
  this.scan_tips();
   
    
  }
  
  ionViewDidLoad() {
    console.log('ionViewDidLoad CoupanCodePage');
  }
  
  // submit(data)
  // {
  //   this.flag=1;
  //   console.log(data);
  //   this.qr_code=data;
  //   this.service.post_rqst({'karigar_id':this.service.karigar_id,'qr_code':this.qr_code},'app_karigar/karigarCoupon').subscribe((r:any)=>
  //   {
  //     console.log(r);
  //     this.success_gif = r.success_gif
  //     console.log("succes image",this.success_gif);
      
  //     if(r['status'] == 'BLANK'){
  //       this.showAlert("This Coupon Code doesn't contain any Value");
  //       return;
  //     }
  //     else if(r['status'] == 'INVALID'){
  //       this.showAlert("Invalid Coupon Code");
  //       return;
  //     }
  //     else if(r['status'] == 'REQUIRED'){
  //       this.showAlert("Please Enter Coupon Code");
  //       return;
  //     }
  //     else if(r['status'] == 'USED'){
  //       this.showAlert("Coupon Already Used");
  //       return;
  //     }
  //     else if(r['status'] == 'UNASSIGNED OFFER'){
  //       this.showAlert("Your Account Under Verification");
  //       return;
  //     }
  //     this.showSuccess( r['coupon_value'] +`<img src="${this.gif_url + this.success_gif}" alt="g-maps" style="border-radius: 2px">`)
  //     // this.navCtrl.setRoot(TabsPage,{index:'0'});
  //     // this.showSuccess( r['coupon_value'] + 'check')
  //     this.navCtrl.push(HomePage);
  //   });
  // }
  total_balance_point:any;
  sharepoint:any=0;
  notify_cn=0;
  offerbanner:any;
  lat:any;
    long:any;
  scan_tips()
  {
      this.locationaccuracy.request(this.locationaccuracy.REQUEST_PRIORITY_HIGH_ACCURACY)
      .then(() => {
          let options = {
              maximumAge: 10000, timeout: 15000, enableHighAccuracy: true
          };
          this.geolocation.getCurrentPosition(options)
          .then((resp) => {
              this.lat = resp.coords.latitude
              this.long = resp.coords.longitude
              console.log(this.lat);
              //  this.getgeocode();
              
              if(this.lat == null && this.long == null){
                  console.log("null lat",this.lat);
                  
              }else{
                  this.scan();
                  //  let options: NativeGeocoderOptions = {
                  //     useLocale: true,
                  //     maxResults: 10
                  //     };
                  
                  // this.nativeGeocoder.reverseGeocode(this.lat, this.long,options)
                  // .then((result: NativeGeocoderReverseResult[]) => 
                  // console.log(JSON.stringify(result[0]),
                  // this.address = this.generateAddress(result[0]),
                  // console.log('subLocality',result[0]),
                  // console.log('subAdministrativeArea',result[0].subAdministrativeArea)
                  
                  // ))
                  
                  // .catch((error: any) => console.log(error));
                  // console.log( "address print",this.address)
                  
              }
              
              
          },
          error => {
              console.log('Error requesting location permissions', error);
              if(error){
                  let alert = this.alertCtrl.create({
                      title:'Alert!',
                      cssClass:'action-close',
                      subTitle:"Enable to get your location so, can't scan",
                      buttons: ['OK']
                  });
                  alert.present();  
              }
              
          });
      });
  }

  qr_count:any=0;
  qr_limit:any=0;
  //  success_gif:any;
  //   gif_url="https://apps.abacusdesk.com/PlusPointLock/dd_api/app/uploads/"
    type_gif:any;
    coupon_value1:any;
  scan(){
    
                this.service.post_rqst({'karigar_id':this.service.karigar_id},"app_karigar/get_qr_permission")
                .subscribe(resp=>{
                    console.log(resp);
                    this.qr_count = resp['karigar_daily_count'];
                    this.qr_limit = resp['qr_limit'];
                    console.log(this.qr_count);
                    console.log(this.qr_limit);
                    
                    if(parseInt(this.qr_count) <= parseInt(this.qr_limit) )
                    {
                        const options:BarcodeScannerOptions =  { 
                            // prompt : "लैमिनेट शीट के स्टीकर को स्कैन करते समय, लाल रंग की लाइन को बारकोड स्टीकर की सभी लाइनों पर डालें स्कैन न होने पर संपर्क करें। कॉल करें- +91-9773897370"
                            prompt : ""
                        };
                        this.barcodeScanner.scan(options).then(resp => {
                            console.log(resp);
                            this.qr_code=resp.text;
                            console.log( this.qr_code);
                            if(resp.text != '')
                            {
                                this.service.post_rqst({'karigar_id':this.service.karigar_id,'qr_code':this.qr_code,'coupon_lat':this.lat,'coupon_long':this.long},'app_karigar/karigarCoupon')
                                .subscribe((r:any)=>
                                {
                                    
                                    console.log(r);
                                    this.success_gif = r.success_gif
                                    console.log("succes image",this.success_gif);
                                    this.coupon_value1= r['coupon_value']
                                    this.type_gif = r.type
                                    
                                    if(r['status'] == 'INVALID'){
                                        this.translate.get("Invalid Coupon Code")
                                        .subscribe(resp=>{
                                            this.showAlert(resp , 'INVALID', `<img src="assets/imgs/cancel.gif"  alt="cancel" style="transform: scale(1);">`);
                                        })
                                        return;
                                    }
                                    else if(r['status'] == 'USED'){
                                        
                                        this.translate.get("Coupon Already Used")
                                        .subscribe(resp=>{

                                            this.showAlert(resp, 'USED', `<img src="assets/imgs/alert.gif"  alt="alert">`);
                                        })
                                        return;
                                    }
                                    else if(r['status'] == 'UNASSIGNED OFFER'){
                                        this.translate.get("Your Account Under Verification")
                                        .subscribe(resp=>{
                                            this.showAlert(resp, 'UNASSIGNED', `<img src="assets/imgs/alert.gif"  alt="alert">`);
                                            
                                        })
                                        return;
                                    }
                                    this.showSuccess( `<img src="assets/imgs/congratulation.gif" alt="g-maps" style="width:100%">`);
                                    // this.getData();
                                    this.navCtrl.pop();

                                });
                            }
                            else{
                                console.log('not scanned anything');
                            }
                        });
                    }
                    else
                    {
                        this.translate.get("You have exceed the daily QR scan limit")
                        .subscribe(resp=>{
                            this.showAlert(resp, '','');
                        })
                    }
                })
            
  }
  showAlert(text, alertTilte, img )
  {
      let alert = this.alertCtrl.create({
          title:alertTilte,
          cssClass:'alert-alert',
          message: img,
          subTitle: text,
          // buttons: ['OK']
      });
      alert.present();
  }
  // scan()
  // {
    
  //   this.barcodeScanner.scan().then(resp => {
  //     console.log(resp);
  //     this.qr_code=resp.text;
  //     console.log( this.qr_code);
  //     if(resp.text != '')
  //     {
  //       this.service.post_rqst({'karigar_id':this.service.karigar_id,'qr_code':this.qr_code},'app_karigar/karigarCoupon').subscribe((r:any)=>
  //       {
  //         console.log(r);
          
  //         if(r['status'] == 'INVALID'){
  //           this.showAlert("Invalid Coupon Code");
  //           return;
  //         }
  //         else if(r['status'] == 'USED'){
  //           this.showAlert("Coupon Already Used");
            
  //           return;
  //         }
  //         else if(r['status'] == 'UNASSIGNED OFFER'){
  //           this.showAlert("Invalid Coupon Code");
  //           return;
  //         }
  //         else if(r['status'] == 'REQUIRED'){
  //           this.showAlert("Please Enter the coupon code ");
  //           return;
  //         }
  //         this.showSuccess( r['coupon_value'] +``)
  //         // this.navCtrl.setRoot(TabsPage,{index:'0'});
  //         this.navCtrl.push(TabsPage);
  //       });
  //     }
  //     else
  //     {
  //       console.log('not scanned anything');
  //     }
  //   });      
  // }
  // showAlert(text)
  // {
  //   let alert = this.alertCtrl.create({
  //     title:'Alert!',
  //     cssClass:'action-close',
  //     subTitle: text,
  //     buttons: ['OK']
  //   });
  //   alert.present();
  // }
  showSuccess(text)
  {
    let alert = this.alertCtrl.create({
      title:'Success!',
      cssClass:'action-close',
      subTitle: text,
      buttons: ['OK']
    });
    alert.present();
  }
}
