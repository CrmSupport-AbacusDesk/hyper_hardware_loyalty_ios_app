import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CompanypolicyPage } from './companypolicy';

@NgModule({
  declarations: [
    CompanypolicyPage,
  ],
  imports: [
    IonicPageModule.forChild(CompanypolicyPage),
  ],
})
export class CompanypolicyPageModule {}
