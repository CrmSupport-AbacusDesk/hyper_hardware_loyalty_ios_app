import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ArrivalProductPage } from './arrival-product';

@NgModule({
  declarations: [
    ArrivalProductPage,
  ],
  imports: [
    IonicPageModule.forChild(ArrivalProductPage),
  ],
})
export class ArrivalProductPageModule {}
