import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FurnitureIdeassharePage } from './furniture-ideasshare';

@NgModule({
  declarations: [
    FurnitureIdeassharePage,
  ],
  imports: [
    IonicPageModule.forChild(FurnitureIdeassharePage),
  ],
})
export class FurnitureIdeassharePageModule {}
